package fitnessclub.com.form;

import lombok.Data;

@Data
public class AssignUserForm {
    public Long activityType;

}
